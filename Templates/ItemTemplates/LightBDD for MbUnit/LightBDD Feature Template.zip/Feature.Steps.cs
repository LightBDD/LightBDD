﻿using LightBDD;
using MbUnit.Framework;

namespace $rootnamespace$
{
	public partial class $safeitemname$: FeatureFixture
	{
		private void Template_method()
		{
		}
	}
}