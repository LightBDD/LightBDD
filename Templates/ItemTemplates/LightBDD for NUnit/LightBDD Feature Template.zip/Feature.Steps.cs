﻿using NUnit.Framework;
using LightBDD;

namespace $rootnamespace$
{
	public partial class $safeitemname$: FeatureFixture
	{
		private void Given_template_method()
		{
		}

		private void When_template_method()
		{
		}

		private void Then_template_method()
		{
		}
	}
}