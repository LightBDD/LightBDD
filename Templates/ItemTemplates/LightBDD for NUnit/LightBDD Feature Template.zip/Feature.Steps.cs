﻿using LightBDD;
using NUnit.Framework;

namespace $rootnamespace$
{
	public partial class $safeitemname$: FeatureFixture
	{
		private void Template_method()
		{
			Assert.Ignore("Not implemented yet");
		}
	}
}