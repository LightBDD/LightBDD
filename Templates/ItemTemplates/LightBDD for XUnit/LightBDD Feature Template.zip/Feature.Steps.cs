﻿using LightBDD;
using Xunit;

namespace $rootnamespace$
{
	public partial class $safeitemname$: FeatureFixture
	{
		private void Template_method()
		{
			ScenarioAssert.Ignore("Not implemented yet");
		}
	}
}