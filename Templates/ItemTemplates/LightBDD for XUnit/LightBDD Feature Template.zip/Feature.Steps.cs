﻿using LightBDD;
using Xunit;
using Xunit.Abstractions;

namespace $rootnamespace$
{
	public partial class $safeitemname$: FeatureFixture
	{
		public $safeitemname$(ITestOutputHelper output) : base(output)
		{
		}

		private void Template_method()
		{
			ScenarioAssert.Ignore("Not implemented yet");
		}
	}
}