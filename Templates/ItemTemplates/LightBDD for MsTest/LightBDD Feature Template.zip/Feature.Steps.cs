﻿using LightBDD;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace $rootnamespace$
{
	public partial class $safeitemname$: FeatureFixture
	{
		private void Template_method()
		{
			Assert.Inconclusive("Not implemented yet");
		}
	}
}