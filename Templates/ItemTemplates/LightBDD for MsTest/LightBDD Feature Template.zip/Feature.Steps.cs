﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using LightBDD;

namespace $rootnamespace$
{
	public partial class $safeitemname$: FeatureFixture
	{
		private void Template_method()
		{
		}
	}
}