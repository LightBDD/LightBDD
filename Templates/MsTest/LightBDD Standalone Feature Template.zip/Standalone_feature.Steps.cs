﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using LightBDD;

namespace $rootnamespace$
{
	public partial class $safeitemname$
	{
		private BDDRunner _runner;

        public $safeitemname$()
        {
            _runner = BDDRunnerFactory.GetRunnerFor(GetType(), () => new ConsoleProgressNotifier());
        }

		private void Given_template_method()
		{
		}

		private void When_template_method()
		{
		}

		private void Then_template_method()
		{
		}
	}
}