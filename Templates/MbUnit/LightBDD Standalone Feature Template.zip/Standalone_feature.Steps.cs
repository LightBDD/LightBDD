﻿using LightBDD;
using MbUnit.Framework;

namespace $rootnamespace$
{
	public partial class $safeitemname$
	{
		private BDDRunner _runner;

		[FixtureSetUp]
		public void FixtureSetUp()
		{
			_runner = new BDDRunner(GetType());
		}

		[FixtureTearDown]
		public void FixtureTearDown()
		{
			var summary = new TestResultsSummary();
			summary.AddResult(_runner.Result);
			summary.SaveSummary(string.Format("{0} summary.xml", GetType().Name));
		}

		private void Given_template_method()
		{
		}

		private void When_template_method()
		{
		}

		private void Then_template_method()
		{
		}
	}
}