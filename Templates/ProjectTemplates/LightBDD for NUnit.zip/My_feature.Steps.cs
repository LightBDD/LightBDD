﻿using NUnit.Framework;
using LightBDD;

namespace $safeprojectname$
{
    public partial class My_feature : FeatureFixture
    {
        private void Given_template_method()
        {
        }

        private void When_template_method()
        {
        }

        private void Then_template_method()
        {
        }
    }
}