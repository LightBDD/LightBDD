﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using LightBDD;

namespace $safeprojectname$
{
	public partial class My_feature: FeatureFixture
	{
		private void Template_method()
		{
		}
	}
}