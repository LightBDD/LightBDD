﻿using LightBDD;
using NUnit.Framework;

namespace $safeprojectname$
{
	public partial class My_feature: FeatureFixture
	{
		private void Template_method()
		{
			Assert.Ignore("Not implemented yet");
		}
	}
}