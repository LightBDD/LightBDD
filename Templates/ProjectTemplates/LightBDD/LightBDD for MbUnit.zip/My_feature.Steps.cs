﻿using LightBDD;
using MbUnit.Framework;

namespace $safeprojectname$
{
	public partial class My_feature: FeatureFixture
	{
		private void Template_method()
		{
			Assert.Inconclusive("Not implemented yet");
		}
	}
}