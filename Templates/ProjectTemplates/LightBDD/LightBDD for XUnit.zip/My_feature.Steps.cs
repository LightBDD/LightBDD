﻿using LightBDD;
using Xunit;

namespace $safeprojectname$
{
	public partial class My_feature: FeatureFixture
	{
		private void Template_method()
		{
			ScenarioAssert.Ignore("Not implemented yet");
		}
	}
}