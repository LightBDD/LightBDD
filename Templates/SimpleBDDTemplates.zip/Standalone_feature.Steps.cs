﻿using NUnit.Framework;

namespace $rootnamespace$
{
	public partial class $safeitemname$
	{
		private BDDRunner _runner;

		[TestFixtureSetUp]
		public void FixtureSetUp()
		{
			_runner = new BDDRunner(GetType());
		}

		[TestFixtureTearDown]
		public void FixtureTearDown()
		{
			var summary = new TestResultsSummary();
			summary.AddResult(_runner.Result);
			summary.SaveSummary(string.Format("{0} summary.xml", GetType().Name));
		}

		private void Given_template_method()
		{
		}

		private void When_template_method()
		{
		}

		private void Then_template_method()
		{
		}
	}
}