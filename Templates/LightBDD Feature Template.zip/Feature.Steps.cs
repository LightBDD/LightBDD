﻿using NUnit.Framework;

namespace $rootnamespace$
{
	public partial class $safeitemname$: FeatureTestsBase
	{
		private void Given_template_method()
		{
		}

		private void When_template_method()
		{
		}

		private void Then_template_method()
		{
		}
	}
}